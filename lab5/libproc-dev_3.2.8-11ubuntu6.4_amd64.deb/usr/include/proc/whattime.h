#ifndef PROC_WHATTIME_H
#define PROC_WHATTIME_H

#include "procps.h"

EXTERN_C_BEGIN

extern void print_uptime(void);
extern char *sprint_uptime(void);

EXTERN_C_END

#endif
